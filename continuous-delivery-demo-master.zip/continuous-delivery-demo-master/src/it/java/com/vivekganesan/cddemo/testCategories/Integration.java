package com.vivekganesan.cddemo.testCategories;

/**
 * Created by Vivek on 19-05-2017.
 */
public interface Integration {
}
